## 说明
这是一个云屋SDK web接口的调用demo，意在让客户更快地了解云屋SDK web接口的调用方式，其代码仅作参考
## 重要
- 接口文档地址：https://sdk.cloudroom.com/sdkdoc/webapi/
- demo入口在test目录下

## 配置
- 运行demo程序之前需要先配置url地址和账号信息
- url地址配置在com.cloudroom.sdkapidemo.constant.UrlConstant#URL
- 账号信息配置在com.cloudroom.sdkapidemo.constant.AuthConstant#COMP_ID和com.cloudroom.sdkapidemo.constant.AuthConstant#COMP_SECRET
### 公网客户
- url地址：https://www.cloudroom.com
- 账号信息可以登录管理后台获取，管理后台地址是https://sdk.cloudroom.com/mgr_sdk/login.html，具体查看方法可到接口文档中查看
- 也可以联系自己的客户经理咨询
### 自建客户
- url地址：自建客户有自己的服务器地址，具体可以咨询相关运维人员
- 自建客户的账号信息默认都是1，如果有修改，需要自行保存