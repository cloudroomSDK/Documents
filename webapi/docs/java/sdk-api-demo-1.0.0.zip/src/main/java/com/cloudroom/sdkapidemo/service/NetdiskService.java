package com.cloudroom.sdkapidemo.service;

import java.io.File;

public interface NetdiskService {

    /**
     * 查询录像
     * @param fileName
     * @return
     * @throws Exception
     */
    String query(String fileName) throws Exception;

    /**
     * 删除录像
     * @param fileName
     * @return
     * @throws Exception
     */
    String delete(String fileName) throws Exception;

    /**
     * 上传录像
     * @param file
     * @param fileName
     * @param dirPath
     * @return
     * @throws Exception
     */
    String upload(File file, String fileName, String dirPath) throws Exception;
}
