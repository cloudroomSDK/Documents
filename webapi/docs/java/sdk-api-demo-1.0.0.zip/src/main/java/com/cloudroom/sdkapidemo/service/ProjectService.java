package com.cloudroom.sdkapidemo.service;

public interface ProjectService {

    String add(String projectName, Integer authType) throws Exception;

    String query() throws Exception;

    String delete(String operateAppId) throws Exception;

    String update(String operateAppId, Integer authType, Integer status) throws Exception;

    String updateSecret(String operateAppId) throws Exception;
}
