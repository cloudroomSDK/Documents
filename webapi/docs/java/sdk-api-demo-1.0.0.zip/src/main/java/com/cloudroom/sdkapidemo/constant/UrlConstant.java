package com.cloudroom.sdkapidemo.constant;

public class UrlConstant {
    // 服务器地址
    public static final String URL = "http://127.0.0.1:2727/";

    // 创建房间URL
    public static final String CREATE_ROOM_URL = URL + "CLOUDROOM-API/room/create";
    // 删除房间URL
    public static final String DELETE_ROOM_URL = URL + "CLOUDROOM-API/room/delete";
    // 查询房间在线人数URL
    public static final String QUERY_ROOM_USERS_NUM_URL = URL + "CLOUDROOM-API/room/onlineUsersNum/query";
    // 查询房间在线成员信息URL
    public static final String QUERY_ROOM_MEMBERS_URL = URL + "CLOUDROOM-API/room/onlineMembers/query";
    // 查询用量（按天统计）URL
    public static final String QUERY_ROOM_USAGE_ALL_URL = URL + "CLOUDROOM-API/room/usageInfo/all/query";
    // 查询用量（按天和房间统计）URL
    public static final String QUERY_ROOM_USAGE_URL = URL + "CLOUDROOM-API/room/usageInfo/query";

    // 新增队列URL
    public static final String ADD_QUEUE_URL = URL + "CLOUDROOM-API/queue/add";
    // 修改队列URL
    public static final String MODIFY_QUEUE_URL = URL + "CLOUDROOM-API/queue/modify";
    // 删除队列URL
    public static final String DELETE_QUEUE_URL = URL + "CLOUDROOM-API/queue/delete";
    // 查询队列URL
    public static final String QUERY_QUEUE_URL = URL + "CLOUDROOM-API/queue/query";

    // 查询录像文件URL
    public static final String QUERY_NETDISK_URL = URL + "CLOUDROOM-API/netDisk/query";
    // 删除录像文件URL
    public static final String DELETE_NETDISK_URL = URL + "CLOUDROOM-API/netDisk/delete";
    // 上传录像文件URL
    public static final String UPLOAD_NETDISK_URL = URL + "CLOUDROOM-API/netDisk/upload";

    // 查询文档URL
    public static final String QUERY_DOC_URL = URL + "CLOUDROOM-API/doc/query";
    // 删除文档URL
    public static final String DELETE_DOC_URL = URL + "CLOUDROOM-API/doc/delete";
    // 上传文档URL
    public static final String UPLOAD_DOC_URL = URL + "CLOUDROOM-API/doc/upload";

    // 创建项目URL
    public static final String ADD_PROJECT_URL = URL + "CLOUDROOM-API/project/add";
    // 查询项目列表URL
    public static final String QUERY_PROJECT_LIST_URL = URL + "CLOUDROOM-API/project/query/list";
    // 删除项目URL
    public static final String DELETE_PROJECT_URL = URL + "CLOUDROOM-API/project/delete";
    // 更新项目URL
    public static final String UPDATE_PROJECT_URL = URL + "CLOUDROOM-API/project/update";
    // 更新项目密钥URL
    public static final String UPDATE_PROJECT_SECRET_URL = URL + "CLOUDROOM-API/project/update/secret";
}
