package com.cloudroom.sdkapidemo.service.impl;

import com.cloudroom.sdkapidemo.bean.BaseDto;
import com.cloudroom.sdkapidemo.bean.RoomDto;
import com.cloudroom.sdkapidemo.constant.UrlConstant;
import com.cloudroom.sdkapidemo.service.RoomService;
import com.cloudroom.sdkapidemo.util.HttpUtil;
import org.springframework.stereotype.Service;

@Service
public class RoomServiceImpl implements RoomService {

    @Override
    public String create() throws Exception {
        return HttpUtil.postToStr(UrlConstant.CREATE_ROOM_URL, new BaseDto().toString());
    }

    @Override
    public String delete(long roomId) throws Exception {
        return HttpUtil.postToStr(UrlConstant.DELETE_ROOM_URL, new RoomDto(roomId).toString());
    }

    @Override
    public String queryOnlineNum(String roomIds) throws Exception {
        return HttpUtil.postToStr(UrlConstant.QUERY_ROOM_USERS_NUM_URL, new RoomDto(roomIds).toString());
    }

    @Override
    public String queryOnlineMembers(long roomId) throws Exception {
        return HttpUtil.postToStr(UrlConstant.QUERY_ROOM_MEMBERS_URL, new RoomDto(roomId).toString());
    }

    @Override
    public String queryUsageInfo(String roomIds, String fromDate, String toDate) throws Exception {
        return HttpUtil.postToStr(UrlConstant.QUERY_ROOM_USAGE_URL, new RoomDto(roomIds, fromDate, toDate).toString());
    }

    @Override
    public String queryAllUsageInfo(String fromDate, String toDate) throws Exception {
        return HttpUtil.postToStr(UrlConstant.QUERY_ROOM_USAGE_ALL_URL, new RoomDto(fromDate, toDate).toString());
    }
}
