package com.cloudroom.sdkapidemo.service.impl;

import com.cloudroom.sdkapidemo.bean.BaseDto;
import com.cloudroom.sdkapidemo.bean.ProjectDto;
import com.cloudroom.sdkapidemo.constant.UrlConstant;
import com.cloudroom.sdkapidemo.service.ProjectService;
import com.cloudroom.sdkapidemo.util.HttpUtil;
import org.springframework.stereotype.Service;

@Service
public class ProjectServiceImpl implements ProjectService {
    @Override
    public String add(String projectName, Integer authType) throws Exception {
        return HttpUtil.postToStr(UrlConstant.ADD_PROJECT_URL, new ProjectDto(projectName, authType).toString());
    }

    @Override
    public String query() throws Exception {
        return HttpUtil.postToStr(UrlConstant.QUERY_PROJECT_LIST_URL, new BaseDto().toString());
    }

    @Override
    public String delete(String operateAppId) throws Exception {
        return HttpUtil.postToStr(UrlConstant.DELETE_PROJECT_URL, new ProjectDto(operateAppId).toString());
    }

    @Override
    public String update(String operateAppId, Integer authType, Integer status) throws Exception {
        return HttpUtil.postToStr(UrlConstant.UPDATE_PROJECT_URL, new ProjectDto(operateAppId, authType, status).toString());
    }

    @Override
    public String updateSecret(String operateAppId) throws Exception {
        return HttpUtil.postToStr(UrlConstant.UPDATE_PROJECT_SECRET_URL, new ProjectDto(operateAppId).toString());
    }
}
