package com.cloudroom.sdkapidemo.service;

import com.cloudroom.sdkapidemo.bean.QueueDto;

public interface QueueService {

    /**
     * 添加队列
     * @param queueDto
     * @return
     * @throws Exception
     */
    String add(QueueDto queueDto) throws Exception;

    /**
     * 修改队列
     * @param queueDto
     * @return
     * @throws Exception
     */
    String modify(QueueDto queueDto) throws Exception;

    /**
     * 删除队列
     * @param queueName
     * @return
     * @throws Exception
     */
    String delete(String queueName) throws Exception;

    /**
     * 查询队列
     * @param queueDto
     * @return
     * @throws Exception
     */
    String query(QueueDto queueDto) throws Exception;
}
