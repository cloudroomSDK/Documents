package com.cloudroom.sdkapidemo.service.impl;

import com.cloudroom.sdkapidemo.bean.QueueDto;
import com.cloudroom.sdkapidemo.constant.UrlConstant;
import com.cloudroom.sdkapidemo.service.QueueService;
import com.cloudroom.sdkapidemo.util.HttpUtil;
import org.springframework.stereotype.Service;

@Service
public class QueueServiceImpl implements QueueService {

    @Override
    public String add(QueueDto queueDto) throws Exception {
        return HttpUtil.postToStr(UrlConstant.ADD_QUEUE_URL, queueDto.toString());
    }

    @Override
    public String modify(QueueDto queueDto) throws Exception {
        return HttpUtil.postToStr(UrlConstant.MODIFY_QUEUE_URL, queueDto.toString());
    }

    @Override
    public String delete(String queueName) throws Exception {
        QueueDto queueDto = new QueueDto(queueName);
        return HttpUtil.postToStr(UrlConstant.DELETE_QUEUE_URL, queueDto.toString());
    }

    @Override
    public String query(QueueDto queueDto) throws Exception {
        return HttpUtil.postToStr(UrlConstant.QUERY_QUEUE_URL, queueDto.toString());
    }
}
