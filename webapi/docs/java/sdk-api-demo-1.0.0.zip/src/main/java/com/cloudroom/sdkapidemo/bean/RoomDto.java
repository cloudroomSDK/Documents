package com.cloudroom.sdkapidemo.bean;

import com.alibaba.fastjson.annotation.JSONField;

public class RoomDto extends BaseDto {

    @JSONField(name = "RoomIds")
    private String roomIds;
    @JSONField(name = "RoomId")
    private Long roomId;
    @JSONField(name = "FromDate")
    private String fromDate;
    @JSONField(name = "ToDate")
    private String toDate;

    public RoomDto(String roomIds){
        this.roomIds = roomIds;
    }

    public RoomDto(Long roomId){
        this.roomId = roomId;
    }

    public RoomDto(String fromDate, String toDate){
        this.fromDate =fromDate;
        this.toDate = toDate;
    }

    public RoomDto(String roomIds, String fromDate, String toDate){
        this(fromDate, toDate);
        this.roomIds = roomIds;
    }

    public String getRoomIds() {
        return roomIds;
    }

    public void setRoomIds(String roomIds) {
        this.roomIds = roomIds;
    }

    public Long getRoomId() {
        return roomId;
    }

    public void setRoomId(Long roomId) {
        this.roomId = roomId;
    }

    public String getFromDate() {
        return fromDate;
    }

    public void setFromDate(String fromDate) {
        this.fromDate = fromDate;
    }

    public String getToDate() {
        return toDate;
    }

    public void setToDate(String toDate) {
        this.toDate = toDate;
    }
}
