package com.cloudroom.sdkapidemo.service;

import java.io.File;

public interface DocService {

    String query(String fileName) throws Exception;

    String delete(String fileName) throws Exception;

    String upload(File file, String fileName, String dirPath) throws Exception;
}
