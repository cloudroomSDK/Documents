package com.cloudroom.sdkapidemo.service;

public interface RoomService {

    /**
     * 创建房间
     * @return
     * @throws Exception
     */
    String create() throws Exception;

    /**
     * 删除房间
     * @param roomId
     * @return
     * @throws Exception
     */
    String delete(long roomId) throws Exception;

    /**
     * 查询在线人数
     * @param roomIds
     * @return
     * @throws Exception
     */
    String queryOnlineNum(String roomIds) throws Exception;

    /**
     * 查询在线人员信息
     * @param roomId
     * @return
     * @throws Exception
     */
    String queryOnlineMembers(long roomId) throws Exception;

    /**
     * 查询指定房间用量信息
     * @param roomIds
     * @param fromDate
     * @param toDate
     * @return
     * @throws Exception
     */
    String queryUsageInfo(String roomIds, String fromDate, String toDate) throws Exception;

    /**
     * 查询所有房间用量信息
     * @param fromDate
     * @param toDate
     * @return
     * @throws Exception
     */
    String queryAllUsageInfo(String fromDate, String toDate) throws Exception;
}
