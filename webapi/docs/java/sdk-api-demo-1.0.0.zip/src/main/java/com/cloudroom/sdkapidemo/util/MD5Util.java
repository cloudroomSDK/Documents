package com.cloudroom.sdkapidemo.util;

import java.security.MessageDigest;

public class MD5Util {
    private static final String HEX_CHARS = "0123456789abcdef";

    private MD5Util() {}

    private static String toHexString(byte[] b) {
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < b.length; i++) {
            sb.append(HEX_CHARS.charAt(b[i] >>> 4 & 0x0F));
            sb.append(HEX_CHARS.charAt(b[i] & 0x0F));
        }
        return sb.toString();
    }

    public static byte[] md5(String data) throws Exception {
        return MessageDigest.getInstance("MD5").digest(data.getBytes());
    }

    public static String md5Hex(String data) {
        try {
            return toHexString(md5(data));
        }catch (Exception e){
            return "";
        }
    }

    public static void main(String[] args) {
        System.out.println(md5Hex("123456"));
    }
}
