package com.cloudroom.sdkapidemo.service.impl;

import com.alibaba.fastjson.JSON;
import com.cloudroom.sdkapidemo.bean.BaseDto;
import com.cloudroom.sdkapidemo.bean.NetdiskDto;
import com.cloudroom.sdkapidemo.constant.UrlConstant;
import com.cloudroom.sdkapidemo.service.NetdiskService;
import com.cloudroom.sdkapidemo.util.HttpUtil;
import org.springframework.stereotype.Service;

import java.io.File;
import java.util.Map;

@Service
public class NetdiskServiceImpl implements NetdiskService {
    @Override
    public String query(String fileName) throws Exception {
        return HttpUtil.postToStr(UrlConstant.QUERY_NETDISK_URL, new NetdiskDto(fileName).toString());
    }

    @Override
    public String delete(String fileName) throws Exception {
        return HttpUtil.postToStr(UrlConstant.DELETE_NETDISK_URL, new NetdiskDto(fileName).toString());
    }

    @Override
    public String upload(File file, String fileName, String dirPath) throws Exception {
        NetdiskDto netdiskDto = new NetdiskDto(fileName, dirPath);
        return HttpUtil.formToStr(UrlConstant.UPLOAD_NETDISK_URL, JSON.parseObject(netdiskDto.toString(), Map.class), file);
    }
}
