package com.cloudroom.sdkapidemo.bean;

import com.alibaba.fastjson.annotation.JSONField;

public class QueueDto extends BaseDto {

    @JSONField(name = "QueueID")
    private Integer queueId;
    @JSONField(name = "QueueName")
    private String queueName;
    @JSONField(name = "NewQueueName")
    private String newQueueName;
    @JSONField(name = "Priority")
    private Integer priority;
    @JSONField(name = "Global")
    private Integer global;
    @JSONField(name = "QueDesc")
    private String queDesc;

    public QueueDto(String queueName){
        this.queueName = queueName;
    }

    public Integer getQueueId() {
        return queueId;
    }

    public void setQueueId(Integer queueId) {
        this.queueId = queueId;
    }

    public String getQueueName() {
        return queueName;
    }

    public void setQueueName(String queueName) {
        this.queueName = queueName;
    }

    public String getNewQueueName() {
        return newQueueName;
    }

    public void setNewQueueName(String newQueueName) {
        this.newQueueName = newQueueName;
    }

    public Integer getPriority() {
        return priority;
    }

    public void setPriority(Integer priority) {
        this.priority = priority;
    }

    public Integer getGlobal() {
        return global;
    }

    public void setGlobal(Integer global) {
        this.global = global;
    }

    public String getQueDesc() {
        return queDesc;
    }

    public void setQueDesc(String queDesc) {
        this.queDesc = queDesc;
    }
}
