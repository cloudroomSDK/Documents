package com.cloudroom.sdkapidemo.bean;

import com.alibaba.fastjson.annotation.JSONField;

public class DocDto extends BaseDto {

    @JSONField(name = "FileName")
    private String fileName;

    @JSONField(name = "DirPath")
    private String dirPath;

    public DocDto(String fileName){
        this.fileName = fileName;
    }

    public DocDto(String fileName, String dirPath){
        this(fileName);
        this.dirPath = dirPath;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getDirPath() {
        return dirPath;
    }

    public void setDirPath(String dirPath) {
        this.dirPath = dirPath;
    }
}
