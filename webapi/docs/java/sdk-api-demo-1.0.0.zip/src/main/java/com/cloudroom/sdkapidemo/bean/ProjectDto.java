package com.cloudroom.sdkapidemo.bean;

import com.alibaba.fastjson.annotation.JSONField;

public class ProjectDto extends BaseDto {

    @JSONField(name = "OperateAppId")
    private String operateAppId;
    @JSONField(name = "ProjectName")
    private String projectName;
    @JSONField(name = "AuthType")
    private Integer authType;
    @JSONField(name = "Status")
    private Integer status;

    public ProjectDto(String projectName, Integer authType){
        this.projectName = projectName;
        this.authType = authType;
    }

    public ProjectDto(String operateAppId){
        this.operateAppId = operateAppId;
    }

    public ProjectDto(String operateAppId, Integer authType, Integer status){
        this(operateAppId);
        this.authType = authType;
        this.status = status;
    }

    public String getOperateAppId() {
        return operateAppId;
    }

    public void setOperateAppId(String operateAppId) {
        this.operateAppId = operateAppId;
    }

    public String getProjectName() {
        return projectName;
    }

    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    public Integer getAuthType() {
        return authType;
    }

    public void setAuthType(Integer authType) {
        this.authType = authType;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }
}
