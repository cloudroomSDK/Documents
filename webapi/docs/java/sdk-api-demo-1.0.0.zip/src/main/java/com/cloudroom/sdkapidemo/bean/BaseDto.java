package com.cloudroom.sdkapidemo.bean;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.annotation.JSONField;
import com.cloudroom.sdkapidemo.constant.AuthConstant;
import com.cloudroom.sdkapidemo.util.MD5Util;

import java.util.UUID;

public class BaseDto {

    // 企业id
    @JSONField(name = "CompID")
    private long compId;
    // 鉴权用到的密钥
    @JSONField(name = "SecretKey")
    private String secretKey;
    // 每次请求API的ID，可用UUID
    @JSONField(name = "RequestId")
    private String requestId;
    // 项目id
    @JSONField(name = "AppId")
    private String appId;
    // 分页每页数量
    @JSONField(name = "PageSize")
    private Integer pageSize;
    // 分页页数
    @JSONField(name = "PageNumber")
    private Integer pageNumber;

    public BaseDto(){
        this.compId = AuthConstant.COMP_ID;
        this.secretKey = MD5Util.md5Hex(this.compId + "&" + AuthConstant.COMP_SECRET);
        this.requestId = UUID.randomUUID().toString();
        this.appId = AuthConstant.APP_ID;
    }

    public BaseDto(long CompID, String SecretKey, String AppId){
        this.compId = CompID;
        this.secretKey = MD5Util.md5Hex(this.compId + "&" + SecretKey);
        this.requestId = UUID.randomUUID().toString();
        this.appId = AppId;
    }


    public long getCompId() {
        return compId;
    }

    public void setCompId(long compId) {
        this.compId = compId;
    }

    public String getSecretKey() {
        return secretKey;
    }

    public void setSecretKey(String secretKey) {
        this.secretKey = secretKey;
    }

    public String getRequestId() {
        return requestId;
    }

    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    public String getAppId() {
        return appId;
    }

    public void setAppId(String appId) {
        this.appId = appId;
    }

    @Override
    public String toString() {
        return JSON.toJSONString(this);
    }

    public Integer getPageSize() {
        return pageSize;
    }

    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }

    public Integer getPageNumber() {
        return pageNumber;
    }

    public void setPageNumber(Integer pageNumber) {
        this.pageNumber = pageNumber;
    }
}
