package com.cloudroom.sdkapidemo.service.impl;

import com.alibaba.fastjson.JSON;
import com.cloudroom.sdkapidemo.bean.DocDto;
import com.cloudroom.sdkapidemo.constant.UrlConstant;
import com.cloudroom.sdkapidemo.service.DocService;
import com.cloudroom.sdkapidemo.util.HttpUtil;
import org.springframework.stereotype.Service;

import java.io.File;
import java.util.Map;

@Service
public class DocServiceImpl implements DocService {
    @Override
    public String query(String fileName) throws Exception {
        return HttpUtil.postToStr(UrlConstant.QUERY_DOC_URL, new DocDto(fileName).toString());
    }

    @Override
    public String delete(String fileName) throws Exception {
        return HttpUtil.postToStr(UrlConstant.DELETE_DOC_URL, new DocDto(fileName).toString());
    }

    @Override
    public String upload(File file, String fileName, String dirPath) throws Exception {
        DocDto docDto = new DocDto(fileName, dirPath);
        return HttpUtil.formToStr(UrlConstant.UPLOAD_DOC_URL, JSON.parseObject(docDto.toString(), Map.class), file);
    }
}
