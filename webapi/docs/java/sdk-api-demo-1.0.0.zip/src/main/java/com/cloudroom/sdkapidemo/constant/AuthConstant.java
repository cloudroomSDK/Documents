package com.cloudroom.sdkapidemo.constant;

public class AuthConstant {

    // 企业id，在云屋科技后台【WEB API】获取，自建版本默认是1
    public static final long COMP_ID = 1L;

    // 企业密钥，在云屋科技后台【WEB API】获取，自建版本默认是“1”
    public static final String COMP_SECRET = "1";

    // 项目id，可在管理后台，【项目管理】项获取，为空则使用默认项目
    public static final String APP_ID = null;
}
