package com.cloudroom.sdkapidemo;

import com.cloudroom.sdkapidemo.service.ProjectService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class ProjectServiceTest {
    private static final String PROJECT_NAME = "sdk_api_demo";
    private static final String OPERATE_APP_ID = "1aa20793ay";

    @Autowired
    private ProjectService projectService;

    @Test
    void add() throws Exception{
        System.out.println(projectService.add(PROJECT_NAME, 0));
    }

    @Test
    void query() throws Exception{
        System.out.println(projectService.query());
    }

    @Test
    void delete() throws Exception{
        System.out.println(projectService.delete(OPERATE_APP_ID));
    }

    @Test
    void update() throws Exception{
        Integer authType = 1, status = 0;
        System.out.println(projectService.update(OPERATE_APP_ID, authType, status));
    }

    @Test
    void updateSecret() throws Exception{
        System.out.println(projectService.updateSecret(OPERATE_APP_ID));
    }
}
