package com.cloudroom.sdkapidemo;

import com.cloudroom.sdkapidemo.service.RoomService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class RoomServiceTest {

    @Autowired
    private RoomService roomService;

    @Test
    void create() throws Exception{
        System.out.println(roomService.create());
    }

    @Test
    void delete() throws Exception {
        long roomId = 99766840L;
        System.out.println(roomService.delete(roomId));
    }

    @Test
    void queryOnlineNum() throws Exception {
        String roomIds = "99766840, 28365858";
        System.out.println(roomService.queryOnlineNum(roomIds));
    }

    @Test
    void queryOnlineMembers() throws Exception {
        long roomId = 28365858L;
        System.out.println(roomService.queryOnlineMembers(roomId));
    }

    @Test
    void queryUsageInfo() throws Exception {
        String roomIds = "99766840, 28365858";
        String fromDate = "2021-12-20";
        String toDate = "2021-12-30";
        System.out.println(roomService.queryUsageInfo(roomIds, fromDate, toDate));
    }

    @Test
    void queryAllUsageInfo() throws Exception {
        String fromDate = "2021-12-20";
        String toDate = "2021-12-30";
        System.out.println(roomService.queryAllUsageInfo(fromDate, toDate));
    }
}
