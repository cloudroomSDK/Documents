package com.cloudroom.sdkapidemo;

import com.cloudroom.sdkapidemo.service.NetdiskService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.io.File;
import java.net.URLEncoder;

@SpringBootTest
public class NetdiskServiceTest {

    @Autowired
    private NetdiskService netdiskService;

    @Test
    void query() throws Exception{
        String fileName = "/2021-12-30/api_upload.mp4";
        System.out.println(netdiskService.query(fileName));
    }

    @Test
    void delete() throws Exception{
        String fileName = "/2021-12-30/api_upload.mp4";
        System.out.println(netdiskService.delete(fileName));
    }

    @Test
    void upload() throws Exception{
        String fileName = URLEncoder.encode("api_upload.mp4", "UTF-8");
        String dirPath = URLEncoder.encode("//2021-12-30", "UTF-8");
        File file = new File("D:\\test.mp4");
        System.out.println(netdiskService.upload(file, fileName, dirPath));
    }
}
