package com.cloudroom.sdkapidemo;

import com.cloudroom.sdkapidemo.bean.QueueDto;
import com.cloudroom.sdkapidemo.service.QueueService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class QueueServiceTest {

    @Autowired
    private QueueService queueService;
    private final static String QUEUE_NAME = "test队列";

    @Test
    void add() throws Exception{
        QueueDto queueDto = new QueueDto(QUEUE_NAME);
        queueDto.setQueDesc("这是一个测试队列");
        System.out.println(queueService.add(queueDto));
    }

    @Test
    void modify() throws Exception{
        QueueDto queueDto = new QueueDto(QUEUE_NAME);
        queueDto.setQueDesc("我修改了测试队列");
        System.out.println(queueService.modify(queueDto));
    }

    @Test
    void delete() throws Exception{
        System.out.println(queueService.delete(QUEUE_NAME));
    }

    @Test
    void query() throws Exception{
        System.out.println(queueService.query(new QueueDto(QUEUE_NAME)));
    }
}
